// create function
function printPDF(){
    console.log("Working on it");
    // Print the current page
    window.print();
    alert("Downloaded Successfully");
} 





